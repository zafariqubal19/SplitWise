USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetUserByEmailId]    Script Date: 1/17/2024 12:03:52 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_GetUserByEmailId]  
  
@Email nvarchar(50)  
AS  
BEGIN   
SELECT * FROM Users WHERE Email=@Email  
END
GO


