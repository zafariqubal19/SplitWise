USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetAllExpenses]    Script Date: 1/17/2024 12:01:23 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_GetAllExpenses]
@GroupId int
AS
BEGIN
SELECT * FROM EXPENSES WHERE GroupId=@GroupId
END
GO


