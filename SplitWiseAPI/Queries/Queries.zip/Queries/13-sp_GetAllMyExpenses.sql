USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetAllMyExpenses]    Script Date: 1/17/2024 12:01:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_GetAllMyExpenses]
@UserId int ,
@GroupId int 
AS
BEGIN
SELECT * FROM EXPENSES WHERE UserId=@UserId AND GroupId=@GroupId
END
GO


