USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[SP_GetAllSplitWiseUsers]    Script Date: 1/17/2024 12:02:16 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[SP_GetAllSplitWiseUsers]
AS 
BEGIN
SELECT * FROM Users
END
GO


