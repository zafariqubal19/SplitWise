USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_UpdateMemberExpense]    Script Date: 1/17/2024 12:07:15 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_UpdateMemberExpense]
@GroupId int,
@TotalAmountSpent int,
@TotalAmountToGive int,
@TotalAmountToReceive int
AS
BEGIN
UPDATE MEMBERS SET TotalAmountSpent=@TotalAmountSpent,TotalAmountToGive=@TotalAmountToGive,TotalAmountToReceive=@TotalAmountToReceive 
WHERE GroupId=@GroupId
END
GO


