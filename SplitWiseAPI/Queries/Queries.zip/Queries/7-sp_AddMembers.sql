USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_AddMembers]    Script Date: 1/17/2024 11:58:52 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [dbo].[sp_AddMembers] 
@GroupId int,
@UserId int 
AS
BEGIN 
INSERT INTO MEMBERS(GroupId,UserId) VALUES(@GroupId,@UserId)
END
GO


