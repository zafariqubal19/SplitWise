USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_IdentifyUser]    Script Date: 1/17/2024 12:05:27 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_IdentifyUser]
@Email nvarchar(50),
@Password nvarchar(50)
AS 
BEGIN
SELECT * FROM USERS WHERE Email=@Email AND Password=@Password
END
GO


