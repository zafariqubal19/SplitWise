USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetUserByUserId]    Script Date: 1/17/2024 12:04:42 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_GetUserByUserId]   
    
@UserId int    
AS    
BEGIN     
SELECT * FROM Users WHERE UserId=@UserId    
END
GO


