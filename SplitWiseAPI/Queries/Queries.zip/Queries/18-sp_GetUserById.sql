USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetUserById]    Script Date: 1/17/2024 12:04:19 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_GetUserById]

@Email nvarchar(50)
AS
BEGIN 
SELECT * FROM Users WHERE Email=@Email
END
GO


