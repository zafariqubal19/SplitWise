USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetGroupDetails]    Script Date: 1/17/2024 12:03:20 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_GetGroupDetails]      
@GroupId int      
AS      
BEGIN      
SELECT m.MemberId, G.GroupName,U.Email,U.Name,m.UserId,G.GroupId,m.TotalAmountSpent,m.TotalAmountToGive,m.TotalAmountToReceive FROM MEMBERS M JOIN GROUPS G ON M.GroupId=G.GroupId    
JOIN USERS U ON U.UserId=M.UserId    
WHERE M.GroupId=@GroupId    
END
GO


