USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_DeleteExpenses]    Script Date: 1/17/2024 11:59:44 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_DeleteExpenses]
@ExpenseId int 
AS
BEGIN 
DELETE FROM EXPENSES WHERE ExpenseId=@ExpenseId
END
GO


