USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_DeleteGroup]    Script Date: 1/17/2024 12:00:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_DeleteGroup]
@GroupId int
AS
BEGIN
DELETE FROM GROUPS WHERE  GroupId=@GroupId
END
GO


