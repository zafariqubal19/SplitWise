USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_getCreatedGroup]    Script Date: 1/17/2024 12:02:38 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_getCreatedGroup]
@UserId int,
@GroupName nvarchar(50)
AS 
BEGIN
SELECT g.GroupId,g.GroupName,g.UserId,u.Email FROM GROUPS g join USERS u on g.UserId=u.UserId WHERE g.UserId=@UserId AND GroupName=@GroupName
END
GO


