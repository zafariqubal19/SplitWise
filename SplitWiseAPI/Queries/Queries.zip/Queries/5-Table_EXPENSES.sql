USE [SplitWiseDB]
GO

/****** Object:  Table [dbo].[EXPENSES]    Script Date: 1/17/2024 11:44:57 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[EXPENSES](
	[ExpenseId] [int] IDENTITY(1,1) NOT NULL,
	[GroupId] [int] NOT NULL,
	[UserId] [int] NOT NULL,
	[Description] [nvarchar](50) NOT NULL,
	[Spender] [nvarchar](50) NOT NULL,
	[TotalAmount] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[ExpenseId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[EXPENSES]  WITH CHECK ADD FOREIGN KEY([GroupId])
REFERENCES [dbo].[GROUPS] ([GroupId])
GO

ALTER TABLE [dbo].[EXPENSES]  WITH CHECK ADD FOREIGN KEY([UserId])
REFERENCES [dbo].[USERS] ([UserId])
GO


