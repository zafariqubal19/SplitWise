USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_AddExpenses]    Script Date: 1/17/2024 11:58:22 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create PROCEDURE [dbo].[sp_AddExpenses]
@GroupId int ,
@UserId int ,
@Description nvarchar(50),
@Spender nvarchar(50),
@TotalAmount int
AS 
BEGIN 
INSERT  INTO EXPENSES (GroupId,UserId,Description,Spender,TotalAmount) VALUES(@GroupId,@UserId,@Description,@Spender,@TotalAmount)
END
GO


