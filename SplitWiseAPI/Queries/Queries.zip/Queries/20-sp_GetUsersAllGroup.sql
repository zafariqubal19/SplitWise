USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_GetUsersAllGroup]    Script Date: 1/17/2024 12:05:02 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_GetUsersAllGroup]        
@UserId INT         
AS         
BEGIN        
select u.UserId, u.Email,u.Name ,g.GroupName ,g.GroupId,g.UserId as 'CreatorId' from MEMBERS m join USERS u  on m.UserId=u.UserId         
join GROUPS g on g.GroupId=m.GroupId        
where m.UserId=@UserId       
END
GO


