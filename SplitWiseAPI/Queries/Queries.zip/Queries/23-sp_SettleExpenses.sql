USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_SettleExpenses]    Script Date: 1/17/2024 12:06:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_SettleExpenses]
@GroupId int
AS
BEGIN
UPDATE MEMBERS SET TotalAmountSpent=0,TotalAmountToGive=0,TotalAmountToReceive=0 WHERE GroupId=@GroupId
END
GO


