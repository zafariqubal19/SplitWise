USE [SplitWiseDB]
GO

/****** Object:  StoredProcedure [dbo].[sp_CreateGroup]    Script Date: 1/17/2024 11:59:21 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[sp_CreateGroup]  
@GroupName nvarchar(50),  
@UserId Int
AS  
BEGIN  
INSERT INTO GROUPS(GroupName,UserId) VALUES (@GroupName,@UserId)  
END
GO


