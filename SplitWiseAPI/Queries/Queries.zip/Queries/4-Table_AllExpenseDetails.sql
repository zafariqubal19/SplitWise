USE [SplitWiseDB]
GO

/****** Object:  Table [dbo].[AllExpenseDetails]    Script Date: 1/17/2024 11:42:33 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[AllExpenseDetails](
	[AllExpenseDetailsId] [int] IDENTITY(1,1) NOT NULL,
	[GroupId] [int] NOT NULL,
	[ExpenseId] [int] NOT NULL,
	[Members] [nvarchar](50) NOT NULL,
	[TotalAmountSpent] [int] NOT NULL,
	[TotalAmountToGive] [int] NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[AllExpenseDetailsId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[AllExpenseDetails]  WITH CHECK ADD FOREIGN KEY([ExpenseId])
REFERENCES [dbo].[EXPENSES] ([ExpenseId])
GO

ALTER TABLE [dbo].[AllExpenseDetails]  WITH CHECK ADD FOREIGN KEY([GroupId])
REFERENCES [dbo].[GROUPS] ([GroupId])
GO


